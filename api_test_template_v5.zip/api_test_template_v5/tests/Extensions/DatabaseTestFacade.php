<?php

namespace App\Tests\Extensions;

use PDO;
use App\Domain\Ports\Database;
use App\Domain\Ports\Database\Columns;
use App\Domain\Ports\Database\Data;
use App\Domain\Ports\Database\ResultRow;
use App\Domain\Ports\Database\ResultRowSet;
use App\Domain\Ports\Database\Table;
use App\Domain\Ports\Database\Where;

class DatabaseTestFacade implements Database
{
    private $dbAdapter;
    private $dirtyTableNames = [];

    public function __construct(Database $dbAdapter)
    {
        $this->dbAdapter = $dbAdapter;
    }

    /**
     * Get the names of all the database tables which have been inserted/updated to,
     * in case you'd want to truncate those tables after/before a test.
     *
     * @return string[]
     */
    public function dirtyTableNames() : array
    {
        return $this->dirtyTableNames;
    }

    public function insert(Table $table, Data $data) : bool
    {
        $this->dirtyTableNames[] = $table->toString();

        return $this->dbAdapter->insert($table, $data);
    }

    public function select(Table $table, Columns $columns, ?Where $where = null) : ?ResultRowSet
    {
        return $this->dbAdapter->select($table, $columns, $where);
    }

    public function selectOne(Table $table, Columns $columns, Where $where) : ?ResultRow
    {
        return $this->dbAdapter->selectOne($table, $columns, $where);
    }

    public function update(Table $table, Data $data, Where $where) : bool
    {
        $this->dirtyTableNames[] = $table->toString();

        return $this->dbAdapter->update($table, $data, $where);
    }

    public function beginTransaction() : bool
    {
        return $this->dbAdapter->beginTransaction();
    }

    public function commit() : bool
    {
        return $this->dbAdapter->commit();
    }

    public function rollBack() : bool
    {
        return $this->dbAdapter->rollBack();
    }

    public function inTransaction() : bool
    {
        return $this->dbAdapter->inTransaction();
    }

    public function PDOInstance() : PDO
    {
        return $this->dbAdapter->PDOInstance();
    }
}