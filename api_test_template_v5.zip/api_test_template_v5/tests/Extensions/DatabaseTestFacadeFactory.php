<?php

namespace App\Tests\Extensions;

use App\Adapter\MedooFactory;
use App\Domain\Ports\Database;

class DatabaseTestFacadeFactory
{
    private static $instance;

    public static function staticDbAdapter() : DatabaseTestFacade
    {
        if (static::$instance === null) {
            static::$instance = new DatabaseTestFacade(static::createDatabaseMedooAdapter());
        }

        return static::$instance;
    }

    private static function createDatabaseMedooAdapter() : Database
    {
        return MedooFactory::createDatabaseAdapter();
    }
}