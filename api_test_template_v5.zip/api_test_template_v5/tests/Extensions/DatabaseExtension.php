<?php

namespace App\Tests\Extensions;

use App\Domain\Ports\Database;
use App\Tests\Traits\HasDatabase;
use PDO;
use PDOException;
use Phinx\Console\PhinxApplication;
use PHPUnit\Runner\AfterLastTestHook;
use PHPUnit\Runner\BeforeFirstTestHook;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Input\StringInput;
use Symfony\Component\Console\Logger\ConsoleLogger;
use Symfony\Component\Console\Output\ConsoleOutput;
use Symfony\Component\Console\Output\NullOutput;

class DatabaseExtension implements BeforeFirstTestHook, AfterLastTestHook
{
    use HasDatabase;

    /** @var Database */
    private $dbh;

    /** @var LoggerInterface  This is a Symfony interface, so no ideal, but not worth changing for now (TODO) */
    private $logger;

    public function executeAfterLastTest() : void
    {
        $this->destroyTemporaryDatabase();
    }

    public function executeBeforeFirstTest() : void
    {
        $this->createTemporaryDatabase();
    }

    /**
     * Creates a new database on the fly and runs the migrations on it.
     */
    private function createTemporaryDatabase() : void
    {
        $this->logger()->info(sprintf('Creating temporary database "%s"', $_ENV['DATABASE_NAME']));

        try {
            $dbh = new PDO(
                sprintf(
                    'pgsql:host=%s user=%s password=%s dbname=%s',
                    $_ENV['DATABASE_HOST'],
                    $_ENV['DATABASE_USER'],
                    $_ENV['DATABASE_PASSWORD'],
                    'template1'
                )
            );

            $dbh->query("DROP DATABASE {$_ENV['DATABASE_NAME']};"); // Just in case the test database still exists
            $dbh->query("CREATE DATABASE {$_ENV['DATABASE_NAME']};");

            $this->dbh = $dbh;

        } catch (PDOException $ex) {
            die(sprintf('Database initiation error: %s' . PHP_EOL, $ex->getMessage()));
        }

        // Run all the migrations on the test database
        $app = new PhinxApplication();
        $app->setAutoExit(false);
        $app->run(new StringInput('migrate'), new NullOutput());
    }

    private function destroyTemporaryDatabase() : void
    {
        if ($this->dbh === null) {
            return;
        }

        echo PHP_EOL;
        $this->logger()->info(sprintf('Destroying temporary database "%s"', $_ENV['DATABASE_NAME']));

        try {
            // $this->dbh->query("DROP DATABASE {$_ENV['DATABASE_NAME']};");
        } catch (PDOException $ex) {
            die(sprintf('Database clean-up error: %s' . PHP_EOL, $ex->getMessage()));
        }
    }

    private function logger() : LoggerInterface
    {
        if (! $this->logger) {
            $this->logger = new ConsoleLogger(new ConsoleOutput(ConsoleOutput::VERBOSITY_DEBUG));
        }

        return $this->logger;
    }
}