<?php
declare(strict_types=1);

namespace App\Tests;

use App\Tests\Traits\HasDatabase;
use Symfony\Bundle\FrameworkBundle\KernelBrowser;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase as SymfonyWebTestCase;

class WebTestCase extends SymfonyWebTestCase
{
    use HasDatabase;

    /** @var KernelBrowser|null */
    private $client = null;

    public function setUp()
    {
        parent::setUp();

        $this->databaseAdapter()->beginTransaction();

        $this->client = static::createClient();
    }

    public function tearDown() : void
    {
        parent::tearDown();

        $this->databaseAdapter()->rollBack();
    }

    public function client() : ?KernelBrowser
    {
        return $this->client;
    }
}