<?php

namespace App\Tests\Traits;

use App\Domain\Ports\Database;
use App\Tests\Extensions\DatabaseTestFacadeFactory;

trait HasDatabase
{
    private $dbAdapter;

    protected function databaseAdapter() : Database
    {
        if ($this->dbAdapter === null) {
            $this->dbAdapter = DatabaseTestFacadeFactory::staticDbAdapter();
        }

        return $this->dbAdapter;
    }
}