<?php

namespace App\Tests\Unit;

use App\Tests\TestCase;

class ExampleTest extends TestCase
{
    public function testConcept() : void
    {
        $this->assertTrue(true);
    }
}