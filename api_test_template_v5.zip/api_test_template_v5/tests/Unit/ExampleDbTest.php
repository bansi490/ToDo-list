<?php
declare(strict_types=1);

namespace App\Tests\Unit;

use App\Domain\Ports\Database\Columns;
use App\Domain\Ports\Database\Data;
use App\Domain\Ports\Database\Table;
use App\Tests\DatabaseTestCase;

class ExampleDbTest extends DatabaseTestCase
{
    /**
     * Basic test to check insert and select on a database adapter,
     * assuming there is a table called 'tasks' with a UUID id column.
     *
     * @covers \App\Domain\Ports\Database\Database::insert
     * @covers \App\Domain\Ports\Database\Database::select
     */
    public function testDatabaseSeedingIsWorking() : void
    {
        $tasksTable = new Table('tasks');
        $taskId     = 'e7eb1f06-94b6-4c10-8e36-eb6dec14b4b8';

        $this->databaseAdapter()->insert(
            $tasksTable,
            new Data(['id' => $taskId])
        );

        $result = ($this->databaseAdapter()->select($tasksTable, Columns::withAllColumns()));

        $this->assertSame(1, $result->count(), 'Expected there to be exactly 1 entry');

        $firstRow = current($result->toArray());

        $this->assertSame($taskId, $firstRow->column('id'));
    }
}