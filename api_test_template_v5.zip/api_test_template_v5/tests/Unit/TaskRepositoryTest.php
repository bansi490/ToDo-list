<?php
declare(strict_types=1);

namespace App\Tests\Unit;

use App\Tests\TestCase;
use App\Domain\ToDo\ReadModel\TaskRepository;

class TaskRepositoryTest extends TestCase
{

    protected function setUp(): void
    {
        $this->getTasks = $this->createMock(taskList);
        $this->addTask = $this->createMock(addNewTask);

        $this->validator = new TaskRepository($this->addTask);
        $this->validator->initialize($this->getTasks);
    }

    public function testAddTask(): void
    {
        $this->addTask->expects($this->once())
            ->method('addTask')
            ->with('test');

        $this->validator->validate('test', new TaskRepository());
    }
}