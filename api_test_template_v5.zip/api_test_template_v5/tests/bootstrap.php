<?php
// Test-specific bootstrap file.

require_once('config/bootstrap.php');

