# Database Tests

## How do I create a test persisting to or reading from the database?

Extend `DatabaseTestCase` for unit tests, and `WebTestCase` for functional web tests. These two classes already support database interactions out of the box.

To insert data into the database for seeding purposes, you can call `$this->databaseAdapter()->insert()` etc.

If you cannot or don't want to extend either, use the trait `HasDatabase` to gain access to the database adapter, and make sure to begin a transaction in `setUp` and roll back in `tearDown`, or optionally truncate dirty tables at the end of each test instead (you can find the table names that have been tampered with using `$this->databaseAdapter()->dirtyTableNames()`).

## Which database is being used by the test suite?

This application creates a temporary test database, as defined in `.env.test`, in the variable `DATABASE_NAME`. So make sure this database name is not the same as your main database, as the test suite will drop and recreate it.

If you need to see what data is in the test database at the end of the test run, comment out the method call to `destroyTemporaryDatabase()` in `App\Tests\Extension\DatabaseExtension::executeAfterLastTest()`.


## What data is in the test database by default?

Nothing. There are no seeders being used.
This is because we want to start each test from a clean slate.
You may choose to use a seeder in your specific test class.

Note: The `WebTestCase` seeds users, to allow tests extending this class to authenticate without having to set up a valid user each time.

## Does the database state persist between tests?

Not if you are extending `DatabaseTestCase` or `WebTestCase`. These open up a transaction before each test and roll back again after each test.

If this does not work for you, you can also call `$this->databaseAdapter()->dirtyTableNames()` to get a list of tables that have been tampered with. You can manually iterate through these and then truncate them all.
To get the PDO instance directly, you can call `$this->databaseAdapter()->PDOInstance()`. Note that for `$this->databaseAdapter` to be available you have to use the trait `HasDatabase` in the tests folder.

## How does it all work?

### PHPUnit extension
We created a PHPUnit Extension which allows us using PHPUnit event hooks, giving us access to execute code before the FIRST test runs as well as after the LAST test has run.

The extension is called `DatabaseExtension`, and is injected into PHPUnit via `phpunit.xml.dist`:

```$xslt
<?xml version="1.0" encoding="UTF-8"?>

<!-- https://phpunit.readthedocs.io/en/latest/configuration.html -->
<phpunit xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="http://schema.phpunit.de/6.5/phpunit.xsd"
    ...
>
    ...

    <extensions>
        <extension class="App\Tests\Extensions\DatabaseExtension" />
    </extensions>
</phpunit>
```

This `DatabaseExtension` connects via `PDO` using the environment variables specified in `.env.test`.

### WebTestCase and DatabaseTestCase

In order to clean the database after each test, we needed to either manually truncate all the tables each time, or keep a list of "dirty" tables and then truncate only those (for performance reasons), or open a transaction before each test and then roll back afterwards.

To get a list of dirty tables, we had to create a wrapper (a facade) for the `Database` port. In this case we implemented a facade for the concrete Database port implementation for Medoo (i.e. the Medoo adapter).
This alone only allows us to get a list of tables used by seeders, but does not allow tracking of which tables have been written to as part of the normal application flow.

To solve this problem, and also to be able to start a transaction before each test case, we had to make sure the same instance of the database adapter was being used across the tests and the application.
To achieve this, we created a factory which keeps a single instance of the database adapter (`DatabaseTestFacadeFactory`) and then created a `config/services_test.yaml` (it's important that it's exactly in that directory) which is used by the test suite only, and (automatically) extends `config/services.yaml`. 
`services_test.yaml` overrides the instructions on how to instantiate the Medoo database instance, which is by using our test-specific Singleton `DatabaseTestFacadeFactory`.
It also specifies all services as public, which is another requirement by tests. Non-public, unused services are automatically removed from the Symfony services container, and won't be usable. "Unused" is everything that hasn't already been injected somewhere before the test starts.