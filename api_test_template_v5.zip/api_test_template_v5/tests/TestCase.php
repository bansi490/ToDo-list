<?php

namespace App\Tests;

use PHPUnit\Framework\TestCase as BaseTestCase;

class TestCase extends BaseTestCase
{
    // In case you want to add something to all test cases (except web test cases, as they extend Symfony's test case).
}