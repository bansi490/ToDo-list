<?php

namespace App\Tests;

use App\Tests\Traits\HasDatabase;
use PHPUnit\Framework\TestCase;

abstract class DatabaseTestCase extends TestCase
{
    use HasDatabase;

    public function setUp()
    {
        parent::setUp();

        $this->databaseAdapter()->beginTransaction();
    }

    public function tearDown() : void
    {
        parent::tearDown();

        $this->databaseAdapter()->rollBack();
    }
}