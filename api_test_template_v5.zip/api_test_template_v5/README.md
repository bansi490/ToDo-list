# Babl Cloud API Test

## Introduction

The purpose of this test is to highlight OOP skills, ability to write automated tests and develop RESTful APIs. This sample application was built with [DDD (Domain Driven Design)](https://www.martinfowler.com/tags/domain%20driven%20design.html), however, it is not a requirement for this test.
The framework used is Symfony 4.4 but don't worry if you are not familiar with it. The project has already been set up and you are not required to use Symfony-specific services. See [below](##-symfony-help) for some helpful information about Symfony.

This technical test is built around a simple ToDo application.
The expected coding standard is the [Doctrine Coding Standard](https://github.com/doctrine/coding-standard).

Bits of the code already exist, however, they are incomplete and/or may need to be refactored to make the code follow [SOLID principles](https://scotch.io/bar-talk/s-o-l-i-d-the-first-five-principles-of-object-oriented-design).

### Folder structure

- **src/Presentation**

This is where the controllers live. (And views, but that is not relevant for an API.)

- **src/Domain**

This is the main area you will be working in. This is where all the business logic lives.

- **tests**

This is where the automated tests go.
There is an example unit test inside.

## Objectives

1) Complete the migration file `db/migrations/20200215140454_create_todo_table.php`

2) Add one endpoint to get the list of ToDos

3) Add one endpoint to save a new ToDo entry

4) Write meaningful tests to cover the endpoints

5) Follow SOLID principles and Doctrine Coding Standards

Please, feel free to display any other skills you have in a way related to the objective, add your personal touch!

## Initial set-up

To be able to run the application, you will need Docker to be installed on your computer. If you don't have it already you can get it here: [Docker](https://docs.docker.com/engine/install/)

1. Check USER_ID in .env and make sure it corresponds to the ID of the user that will be running Docker. The command to check your user ID in Linux and Mac OS is `id -u`.

2. Spin up the Docker containers:

    `docker-compose up -d`

3. Install dependencies inside the Docker PHP container:

    `docker exec -it api_test-app bash`

    `composer install`

4. Finish writing the migration in `db/migrations/20200215140454_create_todo_table.php` before running it (also from within the PHP container) with:

    `phinx migrate`
    
    ...Or, to do a dry run before actually running the migration:
    
    `phinx migrate --dry-run`
    
    We use [Phinx](https://book.cakephp.org/phinx/0/en/contents.html) in this example. The bit you will need the most are the [available data types](https://book.cakephp.org/phinx/0/en/migrations.html#working-with-columns).
    
## Symfony help

If you are unfamiliar with Symfony, here are the only things you may need to know:

### Routing
We have set up the project to use routing using annotation. Just add the annotation to the docblock of your controller method to tell Symfony at which URL the method will be available.

```
/**
 * @Route("/example", methods={"GET", "HEAD"}, name="example.list")
 */
```
This should be pretty self-explanatory. 

You can add parameters and constraints like this - parameters become available as controller arguments:

```
/**
 * @Route("example/{text}", requirements={"text": "\w+"}, methods={"GET", "HEAD"}, name="myExample")
 */
public function example(Request $request, string $text) : Response
```

Parameters are optional if they have a default value in the controller method signature:

```
/**
 * @Route("another/{optional}", requirements={"optional": "\w+"}, methods={"GET"}, name="another")
 */
public function anotherUrl(Request $request, string $optional = 'hello') : Response
```

### Interface-wiring

We have set up Symfony to auto-wire dependencies, i.e. you only need to typehint for a service in a constructor,
and Symfony will search for the class anywhere inside the /src folder.
If found, it will inject it automatically.

If the typehint is for an interface, you will need to tell Symfony which interface implementation to inject.
If there is only one implementation you want to be injected everywhere where the interface is being required,
add this to `config/services.yaml`:

```
App\Domain\Ports\Database: '@App\Adapter\Medoo'
```

`App\Domain\Ports\Database` is the FQN of the interface you are type-hinting.

`App\Adapter\Medoo` is the FQN of the interface implementation you want to be injected everywhere.
Don't forget to put the implementation's FQN in quotes and to prefix it with the `@` symbol.

Also, since this is a YAML file, if it is not working for you, double-check you are using the correct indentation. Your line should be one level below `services` (indented once).

That's it!