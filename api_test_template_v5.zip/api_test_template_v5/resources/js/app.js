// any CSS we require will output into a single css file (app.css in this case)
import '../scss/app.scss';