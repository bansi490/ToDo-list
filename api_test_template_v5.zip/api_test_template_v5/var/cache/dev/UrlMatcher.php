<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/DefaultController, name=DefaultController.indexAction' => [[['_route' => 'app_presentation_api_default_index', '_controller' => 'App\\Presentation\\Api\\Controller\\DefaultController::indexAction'], null, null, null, false, false, null]],
        '/tasks' => [[['_route' => 'task.list', '_controller' => 'App\\Presentation\\Api\\Controller\\Task::list'], null, ['GET' => 0, 'HEAD' => 1], null, false, false, null]],
        '/Task/list' => [[['_route' => 'index', '_controller' => 'App\\Presentation\\Api\\Controller\\Task::list'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
