<?php

use Phinx\Migration\AbstractMigration;

class CreateTasksTable extends AbstractMigration
{
	/**
	 * Change Method.
	 *
	 * Write your reversible migrations using this method.
	 * Remember to call "create()" or "update()" and NOT "save()" when working
	 * with the Table class.
	 */
	public function change()
	{
		$tasks = $this->table('tasks', ['id' => false, 'primary_key' => 'id']);
		$tasks->addColumn('id', 'uuid', ['null' => false])
			->addColumn('task_name', 'string', ['limit' => 100])
			->addColumn('status', 'string', ['limit' => 30])
			->create();
		if ($this->isMigratingUp()) {
				$tasks->insert([['task_name' => 'set up required tools', 'status' => 'work in progress']])
					  ->save();
			}
	}
}
