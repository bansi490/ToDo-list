<?php
declare(strict_types=1);

namespace App\Domain\ToDo\ReadModel\Repository;

use PDO;

/**
 * The table to hold task records.
 */
    define('TASKS_TABLE', 'tasks');

class TaskRepository
{
    private $dbAdapter;

    public function __construct()
    {
        $this->dbAdapter = new PDO(
            sprintf(
                'pgsql:dbname=%s;host=%s user=%s password=%s',
                $_ENV['DATABASE_NAME'],
                $_ENV['DATABASE_HOST'],
                $_ENV['DATABASE_USER'],
                $_ENV['DATABASE_PASSWORD']
            )
        );
    }

    /**
     * Returns an array of All tasks objects.
     *
     * @return array[]
     */
    public function taskList()
    {

        $query = 'SELECT id, task, status ' .
                'FROM ' . TASKS_TABLE . ' ORDER BY name ASC';

        $cache = new Cache(TASKS_TABLE, $query);

       if ($cache->isEmpty()) {
            $result = $this->dbAdapter->Execute($query);

            $all = [];
            while (!$result->EOF) {
                $row                = $result->fields;

                $TaskList           = new TaskList();
                $TaskList->id       = $row['id'];
                $TaskList->task     = $row['task'];
                $TaskList->status   = $row['status'];
                $all[]              = $TaskList;

                $result->MoveNext();
            }
            $cache->setData($all);

            return $all;
        } else {
            return $cache->data;
        }
    }

    public function addNewTask($name, $status){

        $query = 'INSERT INTO ' . TASKS_TABLE . ' (`task`, `status`) VALUES (' .
                $this->dbAdapter->qstr($task) . ', ' .
                $this->dbAdapter->qstr($status) . ')';

        $this->dbAdapter->Execute($query);

        deleteTableCache(TASKS_TABLE);

        return $this->dbAdapter->Insert_ID();
    }
}