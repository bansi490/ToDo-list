<?php
declare(strict_types=1);

namespace App\Domain\ToDo\ReadModel;

/**
 * A list of tasks.
 */
class TaskList
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var string
     */
    private $task;

    /**
     * @var string
     */
    private $status;

    // Get all data relating to a task
    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTask(): ?string
    {
        return $this->task;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    // Set all data relating to a task
    public function setTask(string $task): self
    {
        $this->task = $task;
        return $this;
    }

    public function setStatus(string $status): self
    {
        $this->status = $status;
        return $this;
    }
}
