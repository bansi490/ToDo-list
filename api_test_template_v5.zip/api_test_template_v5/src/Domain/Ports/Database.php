<?php

namespace App\Domain\Ports;

use PDO;
use App\Domain\Ports\Database\Columns;
use App\Domain\Ports\Database\Data;
use App\Domain\Ports\Database\ResultRowSet;
use App\Domain\Ports\Database\Table;
use App\Domain\Ports\Database\Where;
use App\Domain\Ports\Database\ResultRow;

interface Database
{
    public function insert(Table $table, Data $data) : bool;

    public function select(Table $table, Columns $columns, ?Where $where = null) : ?ResultRowSet;

    public function selectOne(Table $table, Columns $columns, Where $where) : ?ResultRow;

    public function update(Table $table, Data $data, Where $where) : bool;

    public function PDOInstance() : PDO;

    public function beginTransaction() : bool;

    public function commit() : bool;

    public function rollBack() : bool;

    public function inTransaction() : bool;
}