<?php

namespace App\Domain\Ports\Database;

use App\Domain\Ports\Database\Exception\ColumnNotFound;

class ResultRow
{
    private $data;

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public function column(string $columnName)
    {
        if (! array_key_exists($columnName, $this->data)) {
            throw new ColumnNotFound($columnName);
        }

        return $this->data[$columnName];
    }
}