<?php

namespace App\Domain\Ports\Database;

class Columns
{
    private $columns;
    private $expression;

    public function __construct(array $columns = [], ?string $expression = null)
    {
        $this->columns    = $columns;
        $this->expression = $expression;
    }

    public static function withColumns(array $columns) : self
    {
        return new self($columns);
    }

    public static function withAllColumns() : self
    {
        return new self([], '*');
    }

    public function toStringOrArray()
    {
        return $this->columns ? $this->columns : $this->expression;
    }
}