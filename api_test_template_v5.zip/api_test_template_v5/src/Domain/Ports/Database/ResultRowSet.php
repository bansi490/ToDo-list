<?php

namespace App\Domain\Ports\Database;

class ResultRowSet
{
    private $rows = [];

    public function __construct(array $rows)
    {
        foreach ($rows as $row) {
            $this->rows[] = new ResultRow($row);
        }
    }

    /**
     * @return ResultRow[]
     */
    public function toArray() : array
    {
        return $this->rows;
    }

    public function count() : int
    {
        return count($this->rows);
    }
}