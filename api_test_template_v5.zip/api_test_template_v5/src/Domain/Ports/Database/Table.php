<?php

namespace App\Domain\Ports\Database;

class Table
{
    private $name;

    public function __construct(string $name)
    {
        $this->name = $name;
    }

    public function toString() : string
    {
        return $this->name;
    }
}