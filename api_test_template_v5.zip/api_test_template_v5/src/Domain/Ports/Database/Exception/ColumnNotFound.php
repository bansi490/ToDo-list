<?php

namespace App\Domain\Ports\Database\Exception;

class ColumnNotFound extends \LogicException implements DatabaseException
{
    public function __construct(string $columnName, ?string $tableName = null)
    {
        $message = sprintf(
            'Attempted to retrieve column "%s", but it does not exist in the result set%s',
            $columnName,
            $tableName ? ' (Table: "' . $tableName . '")' : ''
        );

        parent::__construct($message);
    }
}