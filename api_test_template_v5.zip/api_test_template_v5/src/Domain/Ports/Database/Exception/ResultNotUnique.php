<?php

namespace App\Domain\Ports\Database\Exception;

class ResultNotUnique extends \RuntimeException implements DatabaseException
{
    public function __construct()
    {
        parent::__construct('Too many results returned when only expecting one');
    }
}