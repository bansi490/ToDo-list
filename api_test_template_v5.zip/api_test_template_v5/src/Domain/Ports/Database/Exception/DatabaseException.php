<?php

namespace App\Domain\Ports\Database\Exception;

interface DatabaseException
{

}