<?php

namespace App\Domain\Ports\Database;

class Where
{
    private $where;

    public function __construct(array $where)
    {
        $this->where = $where;
    }

    public function toArray() : array
    {
        return $this->where;
    }
}