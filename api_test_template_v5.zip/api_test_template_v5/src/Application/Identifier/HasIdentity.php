<?php
declare(strict_types=1);

namespace App\Application\Identifier;

trait HasIdentity
{
    /** @var Identifier */
    private $id;

    public function id() : Identifier
    {
        return $this->id;
    }
}