<?php
declare(strict_types=1);

namespace App\Application\Identifier;

interface Identifier
{
    public function toString() : string;

    public function __toString() : string;
}