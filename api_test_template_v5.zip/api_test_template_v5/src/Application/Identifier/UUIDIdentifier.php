<?php
declare(strict_types=1);

namespace App\Application\Identifier;

class UUIDIdentifier implements Identifier
{
    private $uuid;

    private function __construct(string $uuid)
    {
        if (!static::isValid($uuid)) {
            throw new InvalidUUID($uuid);
        }

        $this->uuid = $uuid;
    }

    public function toString() : string
    {
        return $this->uuid;
    }

    public function __toString() : string
    {
        return $this->uuid;
    }

    public static function fromString(string $uuid) : self
    {
        return new static($uuid);
    }

    final public static function generate() : Identifier
    {
        $data = random_bytes(16);

        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10

        return new static(vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4)));
    }

    private static function isValid(string $uuid) : bool
    {
        $regEx = '/^[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$/i';

        return (preg_match($regEx, $uuid) === 1);
    }
}