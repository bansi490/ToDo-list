<?php
declare(strict_types=1);

namespace App\Application\Identifier;

/**
 * This interface is to be implemented by any model that has an Identifier.
 */
interface Identifiable
{
    public function id() : Identifier;
}