<?php
declare(strict_types=1);

namespace App\Presentation\Api\Controller;

use App\Domain\ToDo\ReadModel\Repository\TaskRepository;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class Task extends AbstractController
{
    private TaskRepository $taskRepository;

    /**
     * @Route("/tasks", methods={"GET", "HEAD"}, name="task.list")
     */
    public function list() : Response
    {
        $this->taskRepository = new TaskRepository();
        return $this->json($this->taskRepository->taskList()->toJsonArray());
    }

    
}