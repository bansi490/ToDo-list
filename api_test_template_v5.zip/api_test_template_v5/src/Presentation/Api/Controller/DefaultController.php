<?php
 
namespace App\Presentation\Api\Controller;
 
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
 
class DefaultController extends AbstractController
{
/**
* @Route("/DefaultController, name=DefaultController.indexAction")
*/
  public function indexAction()
  {
    return $this->render('@PresentationApi:Default:index.html.twig');
  }
}