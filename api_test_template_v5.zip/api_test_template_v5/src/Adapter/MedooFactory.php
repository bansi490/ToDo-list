<?php

namespace App\Adapter;

use App\Adapter\Medoo as MedooAdapter;
use Medoo\Medoo;

class MedooFactory
{
	public static function createDatabaseAdapter() : MedooAdapter
	{
		return new MedooAdapter(new Medoo([
			'database_type' => $_ENV['DATABASE_DRIVER'],
			'database_name' => $_ENV['DATABASE_NAME'],
			'server'        => $_ENV['DATABASE_HOST'],
			'username'      => $_ENV['DATABASE_USER'],
			'password'      => $_ENV['DATABASE_PASSWORD'],
			'charset'       => 'utf8',
		]));
	}
}