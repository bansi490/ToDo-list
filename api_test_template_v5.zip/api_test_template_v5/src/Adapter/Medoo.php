<?php

namespace App\Adapter;

use App\Domain\Ports\Database;
use App\Domain\Ports\Database\Columns;
use App\Domain\Ports\Database\Data;
use App\Domain\Ports\Database\Exception\ResultNotUnique;
use App\Domain\Ports\Database\ResultRow;
use App\Domain\Ports\Database\ResultRowSet;
use App\Domain\Ports\Database\Table;
use App\Domain\Ports\Database\Where;
use Medoo\Medoo as MedooModel;

class Medoo implements Database
{
	private $instance;

	public function __construct(MedooModel $instance)
	{
		$this->instance = $instance;
	}

	public function insert(Table $table, Data $data) : bool
	{
		return (bool)$this->instance->insert($table->toString(), $data->toArray());
	}

	public function select(Table $table, Columns $columns, ?Where $where = null) : ?ResultRowSet
	{
		$result = $this->instance->select($table->toString(), $columns->toStringOrArray(), ($where ? $where->toArray() : null));

		if (count($result) === 0) {
			return null;
		}

		return new ResultRowSet($result);
	}

	public function selectOne(Table $table, Columns $columns, Where $where) : ?ResultRow
	{
		$result = $this->instance->select($table->toString(), $columns->toStringOrArray(), $where->toArray());

		if (count($result) === 0) {
			return null;
		}

		if (count($result) > 1) {
			throw new ResultNotUnique(); // TODO: What would we pass in as a message?
		}

		return new ResultRow(current($result));
	}

	public function update(Table $table, Data $data, Where $where) : bool
	{
		/** @var \PDOStatement $result */
		$result = $this->instance->select($table->toString(), $data->toArray(), $where->toArray());

		return $result->rowCount() > 0;
	}

    public function beginTransaction() : bool
    {
        return $this->PDOInstance()->beginTransaction();
    }

    public function commit() : bool
    {
        return $this->PDOInstance()->commit();
    }

    public function rollBack() : bool
    {
        return $this->PDOInstance()->rollBack();
    }

    public function inTransaction() : bool
    {
        return $this->PDOInstance()->inTransaction();
    }

    public function PDOInstance() : \PDO
    {
        return $this->instance->pdo;
    }
}