<?php

return [
	'paths'         => [
		'migrations' => '%%PHINX_CONFIG_DIR%%/db/migrations',
		'seeds'      => '%%PHINX_CONFIG_DIR%%/db/seeds',
	],
	'environments'  => [
		'default_migration_table' => 'migrations',
		'default_database'        => 'current',
		'current'                 => [
			'adapter' => 'pgsql',
            'host'    => $_ENV['DATABASE_HOST'] ?? getenv('DBHOST'),
            'name'    => $_ENV['DATABASE_NAME'] ?? getenv('DBNAME'),
            'user'    => $_ENV['DATABASE_USER'] ?? getenv('DBUSER'),
            'pass'    => $_ENV['DATABASE_PASSWORD'] ?? getenv('DBPWD'),
			'port'    => 5432,
			'charset' => 'utf8',
		],
	],
	'version_order' => 'creation',
];

// return [
// 	'paths'         => [
// 		'migrations' => '%%PHINX_CONFIG_DIR%%/db/migrations',
// 		'seeds'      => '%%PHINX_CONFIG_DIR%%/db/seeds',
// 	],
// 	'environments'  => [
// 		'default_migration_table' => 'migrations',
// 		'default_database'        => 'current',
// 		'current'                 => [
// 			'adapter' => 'pgsql',
//             'host'    => 'localhost',
//             'name'    => 'api_test',
//             'user'    => 'api',
//             'pass'    => 'dev',
// 			'port'    => 5432,
// 			'charset' => 'utf8',
// 		],
// 	],
// 	'version_order' => 'creation',
// ];